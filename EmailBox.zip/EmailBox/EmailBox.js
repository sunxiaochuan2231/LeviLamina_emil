/* jshint esversion: 11 */
// ============================================================
//  EmailBox - 服务器邮箱系统
//  - 玩家 /emil 打开邮箱, 首次需绑定自己的邮箱
//  - OP 通过 GUI 给指定玩家发件: 同时写入游戏内邮箱 + 发送到对方绑定邮箱(SMTP)
//  - 奖励: 可附带"OP当前手持物品" + 设置金币, 玩家在游戏内领取
//  - 玩家上线检测未读邮件
//  依赖: legacy-script-engine-nodejs (内置 nodemailer 走 SMTP)
//  作者: 孙笑川天皇
// ============================================================
ll.registerPlugin("EmailBox", "服务器邮箱系统", [1, 0, 0], { auth: "孙笑川天皇" });

const fs = require("fs");
const DIR = "plugins/EmailBox";
const CFG = DIR + "/config.json";
const BIND = DIR + "/binds.json";
const MAIL = DIR + "/mails.json";


const DEFAULT_CFG = {
    "_说明": "pass为163客户端授权码; 163用 smtp.163.com 端口465 secure=true; 切勿外泄本文件",
    smtp: {
        host: "smtp.163.com",
        port: 465,
        secure: true,
        user: "自己的@163.com",
        pass: "授权码"
    },
    fromName: "服务器邮箱"
};

let config, binds, mails, transporter = null;

function rd(p, def) { try { if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, "utf8")); } catch (e) { logger.error("[EmailBox] 读取失败 " + p + ": " + e); } return def; }
function wr(p, o) { try { fs.mkdirSync(DIR, { recursive: true }); fs.writeFileSync(p, JSON.stringify(o, null, 2)); } catch (e) { logger.error("[EmailBox] 写入失败 " + p + ": " + e); } }
function lc(s) { return String(s).toLowerCase(); }
function saveBinds() { wr(BIND, binds); }
function saveMails() { wr(MAIL, mails); }

function loadAll() {
    config = rd(CFG, null);
    if (!config) { config = JSON.parse(JSON.stringify(DEFAULT_CFG)); wr(CFG, config); logger.info("[EmailBox] 已生成默认配置 " + CFG); }
    if (!config.smtp) config.smtp = DEFAULT_CFG.smtp;
    binds = rd(BIND, {});
    mails = rd(MAIL, {});
}

// ---- SMTP ----
function initSmtp() {
    try {
        const nodemailer = require("nodemailer");
        transporter = nodemailer.createTransport({
            host: config.smtp.host,
            port: config.smtp.port,
            secure: !!config.smtp.secure,
            auth: { user: config.smtp.user, pass: config.smtp.pass }
        });
        logger.info("[EmailBox] SMTP已配置: " + config.smtp.user + " @ " + config.smtp.host + ":" + config.smtp.port);
        transporter.verify(function (err) {
            if (err) logger.warn("[EmailBox] SMTP连接校验未通过(发件时可能失败，检查授权码/端口/网络): " + err);
            else logger.info("[EmailBox] SMTP连接正常，可发件");
        });
    } catch (e) {
        logger.error("[EmailBox] 初始化SMTP失败(检查 node_modules/nodemailer 是否拷全): " + e);
        transporter = null;
    }
}
function sendSmtp(to, subject, text, cb) {
    if (!transporter) { if (cb) cb(new Error("SMTP未初始化")); return; }
    try {
        transporter.sendMail({
            from: '"' + (config.fromName || "服务器邮箱") + '" <' + config.smtp.user + '>',
            to: to, subject: subject, text: text
        }, function (err, info) { if (cb) cb(err, info); });
    } catch (e) { if (cb) cb(e); }
}

// ---- 工具 ----
function fmtTime(ts) {
    try { let d = new Date(ts); let p = n => (n < 10 ? "0" : "") + n; return (d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes()); } catch (e) { return ""; }
}
function getOnlineByName(name) {
    let players = mc.getOnlinePlayers() || [];
    let low = lc(name);
    for (let i = 0; i < players.length; i++) if (lc(players[i].realName) === low) return players[i];
    return null;
}
function snapshotHand(pl) {
    let it;
    try { it = pl.getHand(); } catch (e) { return null; }
    try { if (!it || it.isNull() || it.type === "minecraft:air" || it.count <= 0) return null; } catch (e) { return null; }
    try { return { snbt: it.getNbt().toSNBT(), name: (it.name || it.type), count: it.count }; } catch (e) { return null; }
}
function isEmail(s) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s); }

// ---- 领取奖励 ----
function claimReward(pl, mail) {
    let r = mail.reward;
    let got = [];
    if (r) {
        if (r.item) {
            let it = restoreItem(r);
            if (it) { if (!pl.giveItem(it)) { try { mc.spawnItem(it, pl.pos); } catch (e) {} } got.push((r.itemName || "物品") + " x" + (r.count || 1)); }
            else pl.tell("§e物品还原失败，已跳过");
        }
        if (r.money && r.money > 0) {
            try { if (typeof money !== "undefined") { money.add(pl.xuid, r.money); got.push(r.money + " 金币"); } else pl.tell("§e服务器无经济系统，金币奖励跳过"); } catch (e) {}
        }
    }
    mail.claimed = true; saveMails();
    try { pl.refreshItems(); } catch (e) {}
    pl.tell(got.length ? ("§a已领取: §f" + got.join("、")) : "§7该邮件没有可领取的奖励");
}

// restoreItem 用 reward 对象里的 snbt
function restoreItem(reward) {
    try { return mc.newItem(NBT.parseSNBT(reward.item)); } catch (e) { return null; }
}

// ============================================================
//  表单
// ============================================================
function openMain(pl) {
    let nl = lc(pl.realName);
    let list = mails[nl] || [];
    let unread = list.filter(m => !m.read).length;
    let bound = binds[nl];
    let isop = false; try { isop = pl.isOP(); } catch (e) {}

    let fm = mc.newSimpleForm();
    fm.setTitle("§l§6邮箱");
    fm.setContent("§7绑定邮箱: " + (bound ? ("§a" + bound) : "§c未绑定") + "\n§7邮件: §f" + list.length + " 封，§e" + unread + " 未读");
    fm.addButton("§l查看我的邮件\n§r§7" + unread + " 封未读", "textures/items/book_written");
    fm.addButton(bound ? "§l修改绑定邮箱" : "§l§a绑定我的邮箱", "textures/ui/icon_setting");
    if (isop) fm.addButton("§l§c【管理】发送邮件", "textures/ui/icon_book_writable");

    pl.sendForm(fm, function (p, id) {
        if (id === null || id === undefined) return;
        if (id === 0) showMailList(p);
        else if (id === 1) showBindForm(p);
        else if (id === 2 && isop) showAdminSend(p);
    });
}

function showBindForm(pl) {
    let nl = lc(pl.realName);
    let fm = mc.newCustomForm();
    fm.setTitle("§l绑定邮箱");
    fm.addInput("你的邮箱地址", "example@163.com", binds[nl] || "");
    pl.sendForm(fm, function (p, data) {
        if (!data) return;
        let email = String(data[0] || "").trim();
        if (!isEmail(email)) { p.tell("§c邮箱格式不正确"); return; }
        binds[lc(p.realName)] = email; saveBinds();
        p.tell("§a已绑定邮箱: §f" + email);
    });
}

function showMailList(pl) {
    let nl = lc(pl.realName);
    let list = mails[nl] || [];
    if (!list.length) { pl.tell("§7你还没有邮件"); return; }
    let order = list.map((m, i) => i).reverse();   // 新邮件在前
    let fm = mc.newSimpleForm();
    fm.setTitle("§l我的邮件");
    fm.setContent("§7共 " + list.length + " 封");
    for (let i of order) {
        let m = list[i];
        let tag = m.read ? "§8[已读]" : "§a[未读]";
        let gift = (m.reward && (m.reward.item || (m.reward.money > 0)) && !m.claimed) ? " §6" : "";
        fm.addButton(tag + " §f" + m.title + gift + "\n§r§7" + fmtTime(m.time));
    }
    pl.sendForm(fm, function (p, btn) {
        if (btn === null || btn === undefined) return;
        showMailDetail(p, order[btn]);
    });
}

function showMailDetail(pl, idx) {
    let nl = lc(pl.realName);
    let list = mails[nl] || [];
    let m = list[idx];
    if (!m) { showMailList(pl); return; }
    if (!m.read) { m.read = true; saveMails(); }
    let hasReward = m.reward && (m.reward.item || (m.reward.money > 0));
    let rewardText = "";
    if (hasReward) {
        let parts = [];
        if (m.reward.item) parts.push((m.reward.itemName || "物品") + " x" + (m.reward.count || 1));
        if (m.reward.money > 0) parts.push(m.reward.money + " 金币");
        rewardText = "\n\n§6 奖励: §f" + parts.join("、") + (m.claimed ? " §8(已领取)" : "");
    }
    let fm = mc.newSimpleForm();
    fm.setTitle("§l" + m.title);
    fm.setContent("§7" + fmtTime(m.time) + "\n\n§f" + m.content + rewardText);
    let canClaim = hasReward && !m.claimed;
    if (canClaim) fm.addButton("§l§a领取奖励");
    fm.addButton("§l返回");
    pl.sendForm(fm, function (p, btn) {
        if (btn === null || btn === undefined) return;
        if (canClaim && btn === 0) { claimReward(p, m); showMailDetail(p, idx); }
        else showMailList(p);
    });
}

function showAdminSend(pl) {
    let online = (mc.getOnlinePlayers() || []).map(p => p.realName);
    if (!online.length) online = ["(无在线玩家)"];
    let fm = mc.newCustomForm();
    fm.setTitle("§l§c发送邮件");
    fm.addDropdown("选择在线玩家", online, 0);
    fm.addInput("或手动输入玩家ID(填了则优先)", "", "");
    fm.addInput("标题", "", "系统邮件");
    fm.addInput("内容", "", "");
    fm.addSwitch("同时发送到对方绑定邮箱(SMTP)", true);
    fm.addSwitch("附带我当前手持物品作为奖励", false);
    fm.addInput("金币奖励数量", "0", "0");
    pl.sendForm(fm, function (p, d) {
        if (!d) return;
        let dropIdx = d[0] | 0, manual = String(d[1] || "").trim();
        let title = String(d[2] || "").trim() || "系统邮件";
        let content = String(d[3] || "").trim();
        let alsoEmail = !!d[4], attachItem = !!d[5];
        let moneyAmt = parseInt(d[6]) || 0;

        let target = manual;
        if (!target) { let sel = online[dropIdx]; if (sel && sel !== "(无在线玩家)") target = sel; }
        if (!target) { p.tell("§c请选择或输入目标玩家"); return; }
        if (!content) { p.tell("§c内容不能为空"); return; }

        let reward = { item: null, itemName: null, count: 0, money: moneyAmt };
        if (attachItem) {
            let snap = snapshotHand(p);
            if (snap) { reward.item = snap.snbt; reward.itemName = snap.name; reward.count = snap.count; }
            else p.tell("§e你手上没有物品，本次不附带物品奖励");
        }

        let mail = {
            id: Date.now() + "_" + Math.floor(Math.random() * 1000),
            title: title, content: content, time: Date.now(),
            read: false, reward: reward, claimed: false, from: p.realName
        };
        let nl = lc(target);
        if (!mails[nl]) mails[nl] = [];
        mails[nl].push(mail);
        saveMails();

        let tp = getOnlineByName(target);
        if (tp) tp.tell("§6 你收到一封新邮件！输入 §f/emil §6查看");

        let emailMsg = "";
        if (alsoEmail) {
            let addr = binds[nl];
            if (addr) {
                let body = content + ((reward.item || reward.money > 0) ? "\n\n[本邮件附带游戏内奖励，请登录服务器用 /emil 领取]" : "");
                sendSmtp(addr, title, body, function (err) {
                    let op = getOnlineByName(p.realName);
                    if (err) { logger.error("[EmailBox] 发邮件到 " + addr + " 失败: " + err); if (op) op.tell("§c邮件发送到 " + addr + " 失败: " + err); }
                    else { logger.info("[EmailBox] 已发邮件到 " + addr); if (op) op.tell("§a邮件已成功发送到 §f" + addr); }
                });
                emailMsg = " + 正在发送到邮箱(" + addr + ")";
            } else {
                emailMsg = " §e(对方未绑定邮箱，仅游戏内)";
            }
        }
        p.tell("§a邮件已发给 §f" + target + "§a" +
            (reward.item ? (" 含物品[" + (reward.itemName || "?") + "]") : "") +
            (moneyAmt > 0 ? (" +" + moneyAmt + "金币") : "") + emailMsg);
    });
}

// ============================================================
//  事件 + 命令
// ============================================================
mc.listen("onJoin", function (pl) {
    let xuid = pl.xuid;
    setTimeout(function () {
        let p = mc.getPlayer(xuid);
        if (!p) return;
        let unread = (mails[lc(p.realName)] || []).filter(m => !m.read).length;
        if (unread > 0) p.tell("§6 你有 §e" + unread + " §6封未读邮件，输入 §f/emil §6查看");
    }, 2500);
});

mc.listen("onServerStarted", function () {
    loadAll();
    initSmtp();
    let cmd = mc.newCommand("emil", "打开邮箱", PermType.Any);
    try { cmd.setAlias("email"); } catch (e) {}
    cmd.overload([]);
    cmd.setCallback(function (command, origin, output, results) {
        let pl = origin.player;
        if (!pl) { output.error("仅玩家可用"); return; }
        openMain(pl);
    });
    cmd.setup();
    logger.info("[EmailBox] 加载成功 v1.0.0 | /emil 打开邮箱");
});
